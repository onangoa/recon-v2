# Installation

```bash
npm install
```

## Database Installation

### For SQLite (Default)
```bash
npm install sqlite3
```

### For PostgreSQL
```bash
npm install pg
```

### For MySQL  
```bash
npm install mysql2
```

## Development

```bash
npm run dev
```

## Production

```bash
npm start
```