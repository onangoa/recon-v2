const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const MpesaEncryption = require('./mpesaEncryption');

/**
 * Encryption Utilities for M-Pesa API
 * Provides helper functions for certificate-based encryption
 */
const EncryptionUtils = {
  
  /**
   * Encrypt password using certificate file
   * Wrapper around MpesaEncryption.generateSecurityCredential
   *
   * @param {string} password - The password to encrypt
   * @param {string|null} certPath - Optional path to certificate file
   * @returns {string} Base64 encoded encrypted password
   */
  encryptPassword(password, certPath = null) {
    return MpesaEncryption.generateSecurityCredential(password, certPath);
  },

  /**
   * Encrypt password for specific environment
   * 
   * @param {string} password - The password to encrypt
   * @param {string} environment - 'sandbox' or 'production'
   * @returns {string} Base64 encoded encrypted password
   */
  encryptPasswordForEnvironment(password, environment = 'production') {
    return MpesaEncryption.generateSecurityCredentialForEnvironment(password, environment);
  },

  /**
   * Encrypt initiator password and return security credential
   * Convenience method for common use case
   *
   * @param {string} initiatorPassword - The initiator password to encrypt
   * @param {string} environment - 'sandbox' or 'production'
   * @returns {string} Base64 encoded encrypted password
   */
  createSecurityCredential(initiatorPassword, environment = 'production') {
    return this.encryptPasswordForEnvironment(initiatorPassword, environment);
  },

  /**
   * Validate certificate file and return detailed information
   * 
   * @param {string|null} certPath - Optional path to certificate file
   * @returns {object} Validation result with status and details
   */
  validateCertificate(certPath = null) {
    return MpesaEncryption.validateCertificate(certPath);
  },

  /**
   * Generate security credential from environment variables
   * 
   * @param {object} env - Environment variables object (defaults to process.env)
   * @returns {string} Base64 encoded encrypted password
   * @throws {Error} If required environment variables are missing
   */
  generateFromEnv(env = process.env) {
    const initiatorPassword = env.MPESA_INITIATOR_PASSWORD;
    const environment = env.MPESA_ENVIRONMENT || 'sandbox';

    if (!initiatorPassword) {
      throw new Error('MPESA_INITIATOR_PASSWORD environment variable is required');
    }

    return this.encryptPasswordForEnvironment(initiatorPassword, environment);
  },

  /**
   * Test encryption functionality
   * 
   * @returns {object} Test results including validation and sample encryption
   */
  testEncryption() {
    const certValidation = this.validateCertificate();
    
    if (!certValidation.valid) {
      return {
        success: false,
        validation: certValidation,
        message: 'Certificate validation failed, cannot test encryption'
      };
    }

    try {
      const testPassword = 'TestPassword123';
      const encrypted = this.encryptPassword(testPassword);
      
      return {
        success: true,
        validation: certValidation,
        encryptionTest: {
          original: testPassword,
          encrypted: encrypted,
          encryptedLength: encrypted.length
        },
        message: 'Encryption test completed successfully'
      };
    } catch (error) {
      return {
        success: false,
        validation: certValidation,
        error: error.message,
        message: 'Encryption test failed'
      };
    }
  },

  /**
   * Get certificate information
   * 
   * @returns {object} Certificate file information
   */
  getCertificateInfo() {
    const certPath = path.join(__dirname, '../../cert');
    
    try {
      const files = fs.readdirSync(certPath).filter(file => 
        file.endsWith('.cer') || file.endsWith('.crt') || file.endsWith('.pem')
      );

      return {
        directory: certPath,
        exists: fs.existsSync(certPath),
        certificateFiles: files,
        productionCert: fs.existsSync(path.join(certPath, 'ProductionCertificate.cer')),
        sandboxCert: fs.existsSync(path.join(certPath, 'SandboxCertificate.cer'))
      };
    } catch (error) {
      return {
        directory: certPath,
        exists: false,
        error: error.message,
        certificateFiles: []
      };
    }
  },

  /**
   * Batch encrypt multiple passwords
   * 
   * @param {Array<{password: string, label?: string}>} passwords - Array of passwords to encrypt
   * @param {string} environment - 'sandbox' or 'production'
   * @returns {Array<{original: string, encrypted: string, label?: string, success: boolean, error?: string}>}
   */
  batchEncrypt(passwords, environment = 'production') {
    return passwords.map(({ password, label }) => {
      try {
        const encrypted = this.encryptPasswordForEnvironment(password, environment);
        return {
          original: password,
          encrypted,
          label,
          success: true
        };
      } catch (error) {
        return {
          original: password,
          encrypted: null,
          label,
          success: false,
          error: error.message
        };
      }
    });
  },

  /**
   * Create encryption helper for initialization
   * 
   * @param {object} config - Configuration object
   * @returns {object} Configured encryption helper
   */
  createHelper(config = {}) {
    const {
      initiatorPassword,
      certPath,
      environment = 'production',
      cacheCredential = true
    } = config;

    let cachedCredential = null;

    return {
      getSecurityCredential: () => {
        if (cacheCredential && cachedCredential) {
          return cachedCredential;
        }

        const password = initiatorPassword || process.env.MPESA_INITIATOR_PASSWORD;
        if (!password) {
          throw new Error('Initiator password is required');
        }

        cachedCredential = certPath 
          ? this.encryptPassword(password, certPath)
          : this.encryptPasswordForEnvironment(password, environment);

        return cachedCredential;
      },

      refreshCredential: () => {
        cachedCredential = null;
        return this.getSecurityCredential();
      },

      validate: () => this.validateCertificate(certPath)
    };
  }
};

module.exports = EncryptionUtils;