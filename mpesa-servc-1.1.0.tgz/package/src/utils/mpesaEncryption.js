const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/**
 * M-Pesa Encryption Utility
 * Based on official M-Pesa documentation and PHP reference implementation
 * Matches openssl_public_encrypt with OPENSSL_PKCS1_PADDING
 */
class MpesaEncryption {
  
  /**
   * Generate security credential for API requests
   * This matches the PHP implementation: openssl_public_encrypt with OPENSSL_PKCS1_PADDING
   *
   * @param {string|null} initiatorPassword - The initiator password to encrypt
   * @param {string|null} certPath - Path to the certificate file
   * @returns {string} Base64 encoded encrypted password
   * @throws {Error} If password is empty or encryption fails
   */
  static generateSecurityCredential(initiatorPassword = null, certPath = null) {
    const password = initiatorPassword;
    const certificatePath = certPath || process.env.MPESA_PRODUCTION_CERT_PATH || path.join(__dirname, '../../cert/ProductionCertificate.cer');

    // Validate password - matches PHP: "Initiator password is required for security credential generation"
    if (!password || password.trim() === '') {
      throw new Error('Initiator password is required for security credential generation');
    }

    // Check if certificate file exists - matches PHP: "Certificate file not found"
    if (!fs.existsSync(certificatePath)) {
      throw new Error(`Certificate file not found: ${certificatePath}`);
    }

    try {
      // Read certificate file - matches PHP: file_get_contents($path)
      const publicKeyContent = fs.readFileSync(certificatePath, 'utf-8');
      
      if (!publicKeyContent) {
        throw new Error(`Unable to read certificate file: ${certificatePath}`);
      }

      // Create public key from certificate content
      // This matches PHP: openssl_pkey_get_public($publicKey)
      let publicKey;
      try {
        publicKey = crypto.createPublicKey(publicKeyContent);
      } catch (keyError) {
        throw new Error('Invalid certificate or failed to parse public key');
      }

      // Encrypt password with RSA PKCS1 padding
      // This matches PHP: openssl_public_encrypt($password, $encrypted, $publicKeyResource, OPENSSL_PKCS1_PADDING)
      let encrypted;
      try {
        encrypted = crypto.publicEncrypt({
          key: publicKey,
          padding: crypto.constants.RSA_PKCS1_PADDING
        }, Buffer.from(password, 'utf-8'));
      } catch (encryptError) {
        throw new Error('Encryption failed');
      }

      // Return base64 encoded encrypted password - matches PHP: base64_encode($encrypted)
      return encrypted.toString('base64');
      
    } catch (error) {
      if (error.message.includes('Certificate file not found') || 
          error.message.includes('Unable to read certificate') ||
          error.message.includes('Invalid certificate') ||
          error.message.includes('Encryption failed') ||
          error.message.includes('Initiator password is required')) {
        throw error;
      }
      throw new Error(`Security credential generation failed: ${error.message}`);
    }
  }

  /**
   * Generate security credential for specific environment
   * 
   * @param {string} initiatorPassword - The initiator password to encrypt
   * @param {string} environment - 'sandbox' or 'production'
   * @returns {string} Base64 encoded encrypted password
   */
  static generateSecurityCredentialForEnvironment(initiatorPassword, environment = 'production') {
    let certFilename;
    let certPath;

    if (environment === 'production') {
      certFilename = 'ProductionCertificate.cer';
      certPath = process.env.MPESA_PRODUCTION_CERT_PATH;
    } else {
      certFilename = 'SandboxCertificate.cer';
    }

    certPath = certPath || path.join(__dirname, '../../cert', certFilename);
    return this.generateSecurityCredential(initiatorPassword, certPath);
  }

  /**
   * Validate certificate file and return detailed information
   * 
   * @param {string|null} certPath - Optional path to certificate file
   * @returns {object} Validation result with status and details
   */
  static validateCertificate(certPath = null) {
    const certificatePath = certPath || process.env.MPESA_PRODUCTION_CERT_PATH || path.join(__dirname, '../../cert/ProductionCertificate.cer');
    
    try {
      if (!fs.existsSync(certificatePath)) {
        return {
          valid: false,
          message: 'Certificate file not found',
          path: certificatePath,
          errorCode: 'CERT_NOT_FOUND'
        };
      }

      const publicKeyContent = fs.readFileSync(certificatePath, 'utf-8');
      
      if (!publicKeyContent) {
        return {
          valid: false,
          message: 'Unable to read certificate file',
          path: certificatePath,
          errorCode: 'CERT_READ_FAILED'
        };
      }

      // Try to parse the certificate
      try {
        const publicKey = crypto.createPublicKey({
          key: publicKeyContent,
          format: 'pem',
          type: 'spki'
        });
        
        return {
          valid: true,
          message: 'Certificate is valid and can be used for password encryption',
          path: certificatePath,
          publicKeyFormat: 'PEM',
          algorithm: publicKey.asymmetricKeyDetails?.modulusLength ? `RSA-${publicKey.asymmetricKeyDetails.modulusLength}` : 'Unknown'
        };
      } catch (keyError) {
        return {
          valid: false,
          message: 'Certificate file is invalid or corrupted',
          path: certificatePath,
          error: keyError.message,
          errorCode: 'CERT_INVALID'
        };
      }
    } catch (error) {
      return {
        valid: false,
        message: 'Error validating certificate',
        path: certificatePath,
        error: error.message,
        errorCode: 'CERT_VALIDATION_ERROR'
      };
    }
  }

  /**
   * Generate unique originator conversation ID for B2C/B2B transactions
   * Format: timestamp_randomstring
   * 
   * @returns {string} Unique conversation ID
   */
  static generateOriginatorConversationID() {
    const timestamp = Date.now();
    const randomString = Math.random().toString(36).substring(2, 8);
    return `${timestamp}_${randomString}`;
  }

  /**
   * Validate M-Pesa phone number format
   * Must be in format: 254XXXXXXXXX (12 digits starting with 254)
   * 
   * @param {string} phoneNumber - Phone number to validate
   * @returns {boolean} True if valid, false otherwise
   */
  static validatePhoneFormat(phoneNumber) {
    if (!phoneNumber || typeof phoneNumber !== 'string') {
      return false;
    }
    const phoneRegex = /^254\d{9}$/;
    return phoneRegex.test(phoneNumber);
  }

  /**
   * Format phone number to M-Pesa standard format (254XXXXXXXXX)
   * 
   * @param {string} phoneNumber - Phone number to format
   * @returns {string|null} Formatted phone number or null if invalid
   */
  static formatPhoneNumber(phoneNumber) {
    if (!phoneNumber) return null;
    
    let formattedPhone = phoneNumber.toString().replace(/\s+/g, '').replace(/[-+]/g, '');
    
    // Handle numbers starting with 0
    if (formattedPhone.startsWith('0')) {
      formattedPhone = '254' + formattedPhone.substring(1);
    }
    // Handle numbers not starting with 254
    else if (!formattedPhone.startsWith('254')) {
      formattedPhone = '254' + formattedPhone;
    }
    
    return this.validatePhoneFormat(formattedPhone) ? formattedPhone : null;
  }

  /**
   * Validate Command ID for specific API type
   * 
   * @param {string} commandID - Command ID to validate
   * @param {string} apiType - API type (b2c, b2b, b2pochi, reversal, accountBalance, transactionStatus)
   * @returns {boolean} True if valid, false otherwise
   */
  static validateCommandID(commandID, apiType) {
    const commands = {
      b2c: ['SalaryPayment', 'BusinessPayment', 'PromotionPayment'],
      b2b: ['BusinessPayBill', 'BusinessBuyGoods', 'BusinessToBusinessTransfer'],
      b2pochi: ['BusinessPayToPochi'],
      reversal: ['TransactionReversal'],
      accountBalance: ['AccountBalance'],
      transactionStatus: ['TransactionStatusQuery']
    };

    return commands[apiType] && commands[apiType].includes(commandID);
  }

  /**
   * Format error message based on error code
   * 
   * @param {string} errorCode - Error code from M-Pesa API
   * @param {string} errorDetails - Additional error details
   * @returns {string} Formatted error message
   */
  static formatError(errorCode, errorDetails) {
    const errorMessages = {
      // Server errors
      '500.003.1001': 'Internal Server Error',
      '400.003.01': 'Invalid Access Token',
      '400.003.02': 'Bad Request - Server cannot process the request',
      '500.003.03': 'Quota Violation - Too many requests',
      '404.003.01': 'Resource not found - Invalid endpoint',
      '404.001.04': 'Invalid Authentication Header',
      '400.002.05': 'Invalid Request Payload',
      
      // Transaction errors
      '2001': 'The initiator information is invalid',
      '2006': 'The account status does not allow this transaction',
      '2028': 'The request is not permitted according to product assignment',
      '2040': 'Credit Party customer type cannot be supported',
      '8006': 'The security credential is locked',
      'SFC_IC0003': 'The operator does not exist',
      
      // C2B validation errors
      'C2B00011': 'Invalid MSISDN',
      'C2B00012': 'Invalid Account Number',
      'C2B00013': 'Invalid Amount',
      'C2B00014': 'Invalid KYC Details',
      'C2B00015': 'Invalid Short code',
      'C2B00016': 'Other Error'
    };

    const baseMessage = errorMessages[errorCode] || 'Unknown error occurred';
    return errorDetails ? `${baseMessage}: ${errorDetails}` : baseMessage;
  }

  /**
   * Parse result parameters from M-Pesa callback
   * 
   * @param {object} resultParameters - Result parameters object from callback
   * @returns {object} Parsed parameters as key-value pairs
   */
  static parseResultParameters(resultParameters) {
    const parsed = {};
    
    if (resultParameters && resultParameters.ResultParameter) {
      if (Array.isArray(resultParameters.ResultParameter)) {
        resultParameters.ResultParameter.forEach(param => {
          parsed[param.Key] = param.Value;
        });
      } else if (typeof resultParameters.ResultParameter === 'object') {
        parsed[resultParameters.ResultParameter.Key] = resultParameters.ResultParameter.Value;
      }
    }

    return parsed;
  }
}

module.exports = MpesaEncryption;