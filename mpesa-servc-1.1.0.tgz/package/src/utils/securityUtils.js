const crypto = require('crypto');

class SecurityUtils {
  static encrypt(text, secret) {
    const algorithm = 'aes-256-cbc';
    const key = crypto.scryptSync(secret, 'salt', 32);
    const iv = crypto.randomBytes(16);
    
    const cipher = crypto.createCipheriv(algorithm, key, iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    return iv.toString('hex') + ':' + encrypted;
  }

  static decrypt(encryptedText, secret) {
    const algorithm = 'aes-256-cbc';
    const key = crypto.scryptSync(secret, 'salt', 32);
    const parts = encryptedText.split(':');
    const iv = Buffer.from(parts.shift(), 'hex');
    
    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    let decrypted = decipher.update(parts.join(':'), 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  }

  static generateApiKey() {
    return crypto.randomBytes(32).toString('hex');
  }

  static hashPassword(password) {
    return crypto.createHash('sha256').update(password).digest('hex');
  }

  static generateTimestamp() {
    return new Date().toISOString();
  }

  static validatePhoneNumber(phoneNumber) {
    const phoneRegex = /^254\d{9}$/;
    return phoneRegex.test(phoneNumber);
  }

  static formatPhoneNumber(phoneNumber) {
    if (phoneNumber.startsWith('0')) {
      return '254' + phoneNumber.substring(1);
    }
    if (phoneNumber.startsWith('+')) {
      return phoneNumber.substring(1);
    }
    return phoneNumber;
  }

  static sanitizeInput(input) {
    if (typeof input === 'string') {
      return input.trim();
    }
    return input;
  }
}

module.exports = SecurityUtils;