require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const config = require('./config/config');
const logger = require('./utils/logger');
const MpesaEncryption = require('./utils/mpesaEncryption');
const EncryptionUtils = require('./utils/encryptionUtils');
const { errorHandler } = require('./middleware/authMiddleware');

const paymentRoutes = require('./routes/paymentRoutes');
const stkPushRoutes = require('./routes/stkPushRoutes');
const b2bRoutes = require('./routes/b2bRoutes');
const b2pochiRoutes = require('./routes/b2pochiRoutes');
const c2bRoutes = require('./routes/c2bRoutes');
const b2cRoutes = require('./routes/b2cRoutes');

const callbackRoutes = require('./routes/callbackRoutes');

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use((req, res, next) => {
  if (req.path.length > 1 && req.path.endsWith('/')) {
    const query = req.url.slice(req.path.length);
    const newPath = req.path.slice(0, -1);
    return res.redirect(301, newPath + query);
  }
  next();
});

app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path}`);
  next();
});

app.get('/', (req, res) => {
  res.json({
    message: 'Secure M-Pesa Service API',
    version: '1.1.0',
    environment: config.mpesa.environment,
    features: {
      certificateBasedSecurity: true,
      b2pochiSupport: true,
      enhancedValidation: true,
      comprehensiveErrorHandling: true
    },
    endpoints: {
      payments: '/api/mpesa/payments',
      stkPush: '/api/mpesa/stkpush',
      b2b: '/api/mpesa/b2b',
      b2pochi: '/api/mpesa/b2pochi',
      c2b: '/api/mpesa/c2b',
      b2c: '/api/mpesa/b2c',
      callbacks: '/api/mpesa/callback'
    },
    documentation: {
      phonePayment: {
        endpoint: 'POST /api/mpesa/payments/phone',
        description: 'Initiate payment to phone number'
      },
      pochiPayment: {
        endpoint: 'POST /api/mpesa/payments/pochi',
        description: 'Initiate payment to Pochi La Biashara'
      },
      tillPayment: {
        endpoint: 'POST /api/mpesa/payments/till',
        description: 'Initiate payment to till number'
      },
      paybillPayment: {
        endpoint: 'POST /api/mpesa/payments/paybill',
        description: 'Initiate payment to paybill number'
      },
      stkPush: {
        endpoint: 'POST /api/mpesa/stkpush/initiate',
        description: 'Initiate STK Push payment'
      },
      b2c: {
        endpoint: 'POST /api/mpesa/b2c/payment',
        description: 'Initiate B2C payment'
      },
      b2pochi: {
        endpoint: 'POST /api/mpesa/b2pochi/payment',
        description: 'Initiate B2Pochi payment to customer business wallet'
      },
      b2b: {
        endpoint: 'POST /api/mpesa/b2b/transfer',
        description: 'Initiate B2B transfer'
      },
      c2b: {
        endpoint: 'POST /api/mpesa/c2b/register',
        description: 'Register C2B callback URLs'
      },
      transactions: {
        endpoint: 'GET Transaction Status from M-Pesa API',
        description: 'Check transaction status via M-Pesa API'
      }
    },
    certificateTools: {
      validate: 'npm run cert:validate',
      test: 'npm run cert:test',
      encryptPassword: 'npm run encrypt:password'
    }
  });
});

app.get('/health', (req, res) => {
  const certValidation = EncryptionUtils.validateCertificate();
  
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    environment: config.mpesa.environment,
    certificate: {
      valid: certValidation.valid,
      message: certValidation.message
    }
  });
});

app.get('/api/certificate/validate', (req, res) => {
  const certPath = req.query.path;
  const result = MpesaEncryption.validateCertificate(certPath || null);
  res.json(result);
});

app.get('/api/certificate/info', (req, res) => {
  const info = EncryptionUtils.getCertificateInfo();
  res.json(info);
});

app.get('/api/certificate/test', (req, res) => {
  const testResult = EncryptionUtils.testEncryption();
  res.json(testResult);
});

app.use('/api/mpesa', (req, res, next) => {
  logger.info(`Route hit: ${req.method} ${req.path}`);
  next();
});

app.get('/api/test', (req, res) => {
  logger.info('Test endpoint hit');
  res.json({ success: true, message: 'Test works', path: req.path });
});

app.get('/api/mpesa/test', (req, res) => {
  logger.info('API MPESA test endpoint hit');
  res.json({ success: true, message: 'API MPESA test works', path: req.path });
});

app.use('/api/mpesa', paymentRoutes);
app.use('/api/mpesa', stkPushRoutes);
app.use('/api/mpesa', b2bRoutes);
app.use('/api/mpesa', b2pochiRoutes);
app.use('/api/mpesa', c2bRoutes);
app.use('/api/mpesa', b2cRoutes);
app.use('/api/mpesa', callbackRoutes);

app.use(errorHandler);

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Endpoint not found'
  });
});

const PORT = config.server.port || 3000;

async function startServer() {
  try {
    logger.info('Starting M-Pesa Service...');
    logger.info(`Environment: ${config.mpesa.environment}`);
    
    const certValidation = EncryptionUtils.validateCertificate();
    if (certValidation.valid) {
      logger.info(`✓ Certificate validated: ${certValidation.message}`);
      logger.info(`  Path: ${certValidation.path}`);
    } else {
      logger.warn(`⚠ Certificate validation failed: ${certValidation.message}`);
      logger.warn('  Certificate-based encryption may not work properly');
      logger.warn('  Run "npm run cert:validate" to diagnose certificate issues');
    }

    const certInfo = EncryptionUtils.getCertificateInfo();
    logger.info(`Certificate Directory: ${certInfo.directory}`);
    logger.info(`Production Certificate: ${certInfo.productionCert ? '✓ Found' : '✗ Not found'}`);
    logger.info(`Sandbox Certificate: ${certInfo.sandboxCert ? '✓ Found' : '✗ Not found'}`);

    app.listen(PORT, () => {
      logger.info(`✓ Server running on port ${PORT}`);
      logger.info(`✓ B2Pochi Support: Enabled`);
      logger.info(`✓ Certificate-based encryption: ${certValidation.valid ? 'Enabled' : 'Disabled'}`);
      logger.info(`✓ API Documentation available at http://localhost:${PORT}/`);
      logger.info(`✓ Health check available at http://localhost:${PORT}/health`);
      logger.info(`✓ Database integration: Consuming project should implement transaction storage`);
    });
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

module.exports = app;