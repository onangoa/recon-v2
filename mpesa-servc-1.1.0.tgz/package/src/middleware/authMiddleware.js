const rateLimit = require('express-rate-limit');
const SecurityUtils = require('../utils/securityUtils');
const logger = require('../utils/logger');
const config = require('../config/config');

const rateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

const strictRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: 'Too many critical requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

const apiKeyAuth = (req, res, next) => {
  try {
    const apiKey = req.headers['x-api-key'] || req.headers.authorization?.replace('Bearer ', '');
    const configuredKey = config.server.apiKey || process.env.API_KEY;

    logger.info(`API Key Auth: Path=${req.path}, KeyPresent=${!!apiKey}, ConfiguredKey=${configuredKey}`);

    if (!apiKey) {
      logger.warn(`Missing API key for path: ${req.path}`);
      return res.status(401).json({
        success: false,
        message: 'API key required'
      });
    }

    if (!configuredKey) {
      logger.error('API key not configured in server config');
      return res.status(500).json({
        success: false,
        message: 'API key not configured'
      });
    }

    if (apiKey !== configuredKey) {
      logger.warn(`Invalid API key attempt from ${req.ip}. Expected: ${configuredKey}, Received: ${apiKey}`);
      return res.status(403).json({
        success: false,
        message: 'Invalid API key'
      });
    }

    logger.info(`API key authenticated successfully for path: ${req.path}`);
    next();
  } catch (error) {
    logger.error('API key authentication error:', error);
    res.status(500).json({
      success: false,
      message: 'Authentication error'
    });
  }
};

const validatePaymentRequest = (req, res, next) => {
  try {
    const { phoneNumber, amount } = req.body;

    if (!phoneNumber || !amount) {
      return res.status(400).json({
        success: false,
        message: 'Phone number and amount are required'
      });
    }

    const formattedPhone = SecurityUtils.formatPhoneNumber(phoneNumber);
    if (!SecurityUtils.validatePhoneNumber(formattedPhone)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
      });
    }

    if (isNaN(amount) || amount <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Amount must be a positive number'
      });
    }

    req.body.phoneNumber = formattedPhone;
    req.body.amount = parseFloat(amount);

    next();
  } catch (error) {
    logger.error('Payment validation error:', error);
    res.status(500).json({
      success: false,
      message: 'Validation error'
    });
  }
};

const validateTransactionRequest = (req, res, next) => {
  try {
    const { transactionID } = req.body || req.params;

    if (!transactionID) {
      return res.status(400).json({
        success: false,
        message: 'Transaction ID is required'
      });
    }

    next();
  } catch (error) {
    logger.error('Transaction validation error:', error);
    res.status(500).json({
      success: false,
      message: 'Validation error'
    });
  }
};

const sanitizeInputs = (req, res, next) => {
  try {
    if (req.body) {
      Object.keys(req.body).forEach(key => {
        if (typeof req.body[key] === 'string') {
          req.body[key] = SecurityUtils.sanitizeInput(req.body[key]);
        }
      });
    }

    if (req.query) {
      Object.keys(req.query).forEach(key => {
        if (typeof req.query[key] === 'string') {
          req.query[key] = SecurityUtils.sanitizeInput(req.query[key]);
        }
      });
    }

    next();
  } catch (error) {
    logger.error('Sanitization error:', error);
    res.status(500).json({
      success: false,
      message: 'Sanitization error'
    });
  }
};

const errorHandler = (err, req, res, next) => {
  logger.error('Error occurred:', err);

  if (err.name === 'ValidationError') {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      error: err.message
    });
  }

  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({
      success: false,
      message: 'Unauthorized'
    });
  }

  res.status(500).json({
    success: false,
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'production' ? 'An error occurred' : err.message
  });
};

module.exports = {
  rateLimiter,
  strictRateLimiter,
  apiKeyAuth,
  validatePaymentRequest,
  validateTransactionRequest,
  sanitizeInputs,
  errorHandler
};