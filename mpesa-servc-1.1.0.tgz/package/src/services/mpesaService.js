const axios = require('axios');
const config = require('../config/config');
const logger = require('../utils/logger');
const MpesaEncryption = require('../utils/mpesaEncryption');

class MpesaService {
  constructor() {
    this.accessToken = null;
    this.tokenExpiry = null;
  }

  async getAccessToken() {
    try {
      if (this.accessToken && this.tokenExpiry && Date.now() < this.tokenExpiry) {
        return this.accessToken;
      }

      const auth = Buffer.from(
        `${config.mpesa.consumerKey}:${config.mpesa.consumerSecret}`
      ).toString('base64');

      const mpesaUrls = config.getMpesaUrls();
      logger.info(`Getting access token from: ${mpesaUrls.auth}`);
      logger.info(`Environment: ${config.mpesa.environment}`);
      logger.info(`Consumer Key: ${config.mpesa.consumerKey}`);
      logger.info(`Consumer Secret: ${config.mpesa.consumerSecret}`);

      const response = await axios.get(mpesaUrls.auth, {
        headers: {
          Authorization: `Basic ${auth}`
        }
      });

      this.accessToken = response.data.access_token;
      this.tokenExpiry = Date.now() + (3500 * 1000);

      logger.info(`Access token obtained successfully`);
      return this.accessToken;
    } catch (error) {
      logger.error('Error getting access token:', error.message);
      if (error.response) {
        logger.error('Access token error response:', JSON.stringify(error.response.data));
      }
      throw new Error('Failed to get access token');
    }
  }

  async stkPush({ phoneNumber, amount, accountReference, transactionDesc, callbackURL }) {
    try {
      const accessToken = await this.getAccessToken();
      const mpesaUrls = config.getMpesaUrls();
      const date = new Date();
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const seconds = String(date.getSeconds()).padStart(2, '0');
      const timestamp = `${year}${month}${day}${hours}${minutes}${seconds}`;
      
      const password = Buffer.from(
        `${config.mpesa.shortCode}${config.mpesa.passKey}${timestamp}`
      ).toString('base64');

      const formattedPhone = MpesaEncryption.formatPhoneNumber(phoneNumber);

      const payload = {
        BusinessShortCode: config.mpesa.shortCode,
        Password: password,
        Timestamp: timestamp,
        TransactionType: 'CustomerPayBillOnline',
        Amount: parseInt(amount),
        PartyA: formattedPhone,
        PartyB: config.mpesa.shortCode,
        PhoneNumber: formattedPhone,
        CallBackURL: callbackURL || config.mpesa.callbackUrl,
        AccountReference: accountReference,
        TransactionDesc: transactionDesc || 'Payment'
      };

      logger.info(`STK Push Request: ${JSON.stringify(payload)}`);
      logger.info(`STK Push URL: ${mpesaUrls.stkPush}`);
      logger.info(`STK Push Token: ${accessToken.substring(0, 20)}...`);

      const response = await axios.post(mpesaUrls.stkPush, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      logger.info(`STK Push Response: ${JSON.stringify(response.data)}`);
      return response.data;
    } catch (error) {
      logger.error('STK Push error:', error.message);
      if (error.response) {
        logger.error('STK Push error response:', JSON.stringify(error.response.data));
      }
      throw error;
    }
  }

  async queryStkPush(checkoutRequestID) {
    try {
      const accessToken = await this.getAccessToken();
      const mpesaUrls = config.getMpesaUrls();
      const date = new Date();
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const seconds = String(date.getSeconds()).padStart(2, '0');
      const timestamp = `${year}${month}${day}${hours}${minutes}${seconds}`;
      
      const password = Buffer.from(
        `${config.mpesa.shortCode}${config.mpesa.passKey}${timestamp}`
      ).toString('base64');

      const payload = {
        BusinessShortCode: config.mpesa.shortCode,
        Password: password,
        Timestamp: timestamp,
        CheckoutRequestID: checkoutRequestID
      };

      logger.info(`STK Push Query Request: ${JSON.stringify(payload)}`);

      const response = await axios.post(mpesaUrls.stkPushQuery, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      logger.info(`STK Push Query Response: ${JSON.stringify(response.data)}`);
      return response.data;
    } catch (error) {
      logger.error('STK Push query error:', error.message);
      if (error.response) {
        logger.error('STK Push query error response:', JSON.stringify(error.response.data));
      }
      throw error;
    }
  }

  async b2c({ initiatorName, securityCredential, commandID, amount, partyA, partyB, remarks, occasion }) {
    try {
      const accessToken = await this.getAccessToken();
      const mpesaUrls = config.getMpesaUrls();
      const originatorConversationID = MpesaEncryption.generateOriginatorConversationID();

      const environment = config.mpesa.environment || 'production';
      
      const credential = securityCredential || (() => {
        const password = config.mpesa.initiatorPassword;
        if (password) {
          return MpesaEncryption.generateSecurityCredentialForEnvironment(password, environment);
        }
        return config.mpesa.securityCredential;
      })();

      const payload = {
        OriginatorConversationID: originatorConversationID,
        InitiatorName: initiatorName || config.mpesa.initiatorName,
        SecurityCredential: credential,
        CommandID: commandID || 'BusinessPayment',
        Amount: amount.toString(),
        PartyA: partyA || config.mpesa.shortCode,
        PartyB: partyB,
        Remarks: remarks || 'B2C Payment',
        QueueTimeOutURL: config.mpesa.queueTimeoutUrl,
        ResultURL: config.mpesa.resultUrl,
        Occasion: occasion || ''
      };

      const response = await axios.post(mpesaUrls.b2c, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data;
    } catch (error) {
      logger.error('B2C error:', error.message);
      throw error;
    }
  }

  async b2b({ initiatorName, securityCredential, commandID, senderIdentifierType, receiverIdentifierType, amount, partyA, partyB, remarks, accountReference, requester }) {
    try {
      const accessToken = await this.getAccessToken();
      const mpesaUrls = config.getMpesaUrls();
      const originatorConversationID = MpesaEncryption.generateOriginatorConversationID();

      logger.info('B2B Transaction initiated with originatorConversationId:', originatorConversationID);
      logger.info('B2B Request details:', JSON.stringify({ amount, partyA, partyB, accountReference, remarks }));

      const environment = config.mpesa.environment || 'production';
      
      const credential = securityCredential || (() => {
        const password = config.mpesa.initiatorPassword;
        if (password) {
          return MpesaEncryption.generateSecurityCredentialForEnvironment(password, environment);
        }
        return config.mpesa.securityCredential;
      })();

      const payload = {
        Initiator: initiatorName || config.mpesa.initiatorName,
        SecurityCredential: credential,
        CommandID: commandID || 'BusinessPayBill',
        SenderIdentifierType: senderIdentifierType || '4',
        RecieverIdentifierType: receiverIdentifierType || '4',
        Amount: amount.toString(),
        PartyA: partyA,
        PartyB: partyB,
        AccountReference: accountReference,
        Remarks: remarks || 'B2B Payment',
        QueueTimeOutURL: config.mpesa.queueTimeoutUrl,
        ResultURL: config.mpesa.b2bResultUrl || config.mpesa.resultUrl,
        Occasion: ''
      };

      if (requester) {
        payload.Requester = requester;
      }

      logger.info(`B2B Request: ${JSON.stringify(payload)}`);
      logger.info(`B2B URL: ${mpesaUrls.b2b}`);

      const response = await axios.post(mpesaUrls.b2b, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      logger.info(`B2B Response: ${JSON.stringify(response.data)}`);
      return response.data;
    } catch (error) {
      logger.error('B2B error:', error.message);
      if (error.response) {
        logger.error('B2B error response:', JSON.stringify(error.response.data));
      }
      throw error;
    }
  }

  async b2pochi({ initiatorName, securityCredential, amount, partyA, partyB, remarks, occasion }) {
    try {
      const accessToken = await this.getAccessToken();
      const mpesaUrls = config.getMpesaUrls();
      const originatorConversationID = MpesaEncryption.generateOriginatorConversationID();

      const environment = config.mpesa.environment || 'production';
      
      const credential = securityCredential || (() => {
        const password = config.mpesa.initiatorPassword;
        if (password) {
          return MpesaEncryption.generateSecurityCredentialForEnvironment(password, environment);
        }
        return config.mpesa.securityCredential;
      })();

      const payload = {
        OriginatorConversationID: originatorConversationID,
        InitiatorName: initiatorName || config.mpesa.initiatorName,
        SecurityCredential: credential,
        CommandID: 'BusinessPayToPochi',
        Amount: amount.toString(),
        PartyA: partyA || config.mpesa.shortCode,
        PartyB: partyB,
        Remarks: remarks || 'Pochi Payment',
        QueueTimeOutURL: config.mpesa.queueTimeoutUrl,
        ResultURL: config.mpesa.b2pochiResultUrl || config.mpesa.resultUrl,
        Occasion: occasion || ''
      };

      const response = await axios.post(mpesaUrls.b2pochi, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data;
    } catch (error) {
      logger.error('B2Pochi error:', error.message);
      throw error;
    }
  }

  async c2bRegister({ shortCode, validationURL, confirmationURL, responseType }) {
    try {
      const accessToken = await this.getAccessToken();
      const mpesaUrls = config.getMpesaUrls();

      const payload = {
        ShortCode: shortCode || config.mpesa.shortCode,
        ResponseType: responseType || 'Completed',
        ConfirmationURL: confirmationURL || `${config.mpesa.callbackUrl}/confirmation`,
        ValidationURL: validationURL || `${config.mpesa.callbackUrl}/validation`
      };

      const response = await axios.post(mpesaUrls.c2b.register, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data;
    } catch (error) {
      logger.error('C2B Register error:', error.message);
      throw error;
    }
  }

  async c2bSimulate({ shortCode, commandID, amount, msisdn, billRefNumber }) {
    try {
      const accessToken = await this.getAccessToken();
      const mpesaUrls = config.getMpesaUrls();

      const payload = {
        ShortCode: shortCode || config.mpesa.shortCode,
        CommandID: commandID || 'CustomerPayBillOnline',
        Amount: parseInt(amount),
        Msisdn: msisdn,
        BillRefNumber: billRefNumber || ''
      };

      const response = await axios.post(mpesaUrls.c2b.simulate, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data;
    } catch (error) {
      logger.error('C2B Simulate error:', error.message);
      throw error;
    }
  }

  async accountBalance({ initiatorName, securityCredential, commandID, partyA, identifierType, remarks }) {
    try {
      const accessToken = await this.getAccessToken();
      const mpesaUrls = config.getMpesaUrls();
      const originatorConversationID = MpesaEncryption.generateOriginatorConversationID();

      const environment = config.mpesa.environment || 'production';
      
      const credential = securityCredential || (() => {
        const password = config.mpesa.initiatorPassword;
        if (password) {
          return MpesaEncryption.generateSecurityCredentialForEnvironment(password, environment);
        }
        return config.mpesa.securityCredential;
      })();

      const payload = {
        OriginatorConversationID: originatorConversationID,
        Initiator: initiatorName || config.mpesa.initiatorName,
        SecurityCredential: credential,
        CommandID: commandID || 'AccountBalance',
        PartyA: partyA || config.mpesa.shortCode,
        IdentifierType: identifierType || '4',
        Remarks: remarks || 'Balance Query',
        QueueTimeOutURL: config.mpesa.queueTimeoutUrl,
        ResultURL: config.mpesa.accountBalanceResultUrl || config.mpesa.resultUrl
      };

      const response = await axios.post(mpesaUrls.accountBalance, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data;
    } catch (error) {
      logger.error('Account Balance error:', error.message);
      throw error;
    }
  }

  async transactionStatus({ initiatorName, securityCredential, transactionID, originalConversationID, partyA, identifierType, remarks, occasion }) {
    try {
      const accessToken = await this.getAccessToken();
      const mpesaUrls = config.getMpesaUrls();
      const originatorConversationID = MpesaEncryption.generateOriginatorConversationID();

      const environment = config.mpesa.environment || 'production';
      
      const credential = securityCredential || (() => {
        const password = config.mpesa.initiatorPassword;
        if (password) {
          return MpesaEncryption.generateSecurityCredentialForEnvironment(password, environment);
        }
        return config.mpesa.securityCredential;
      })();

      const payload = {
        OriginatorConversationID: originatorConversationID,
        Initiator: initiatorName || config.mpesa.initiatorName,
        SecurityCredential: credential,
        CommandID: 'TransactionStatusQuery',
        TransactionID: transactionID,
        PartyA: partyA || config.mpesa.shortCode,
        IdentifierType: identifierType || '4',
        ResultURL: config.mpesa.transactionStatusResultUrl || config.mpesa.resultUrl,
        QueueTimeOutURL: config.mpesa.queueTimeoutUrl,
        Remarks: remarks || 'Transaction Status',
        Occasion: occasion || ''
      };

      const response = await axios.post(mpesaUrls.transactionStatus, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data;
    } catch (error) {
      logger.error('Transaction Status error:', error.message);
      throw error;
    }
  }

  async reversal({ initiatorName, securityCredential, transactionID, amount, receiverParty, receiverIdentifierType, remarks, occasion }) {
    try {
      const accessToken = await this.getAccessToken();
      const mpesaUrls = config.getMpesaUrls();
      const originatorConversationID = MpesaEncryption.generateOriginatorConversationID();

      const environment = config.mpesa.environment || 'production';
      
      const credential = securityCredential || (() => {
        const password = config.mpesa.initiatorPassword;
        if (password) {
          return MpesaEncryption.generateSecurityCredentialForEnvironment(password, environment);
        }
        return config.mpesa.securityCredential;
      })();

      const payload = {
        OriginatorConversationID: originatorConversationID,
        Initiator: initiatorName || config.mpesa.initiatorName,
        SecurityCredential: credential,
        CommandID: 'TransactionReversal',
        TransactionID: transactionID,
        Amount: amount.toString(),
        ReceiverParty: receiverParty || config.mpesa.shortCode,
        RecieverIdentifierType: receiverIdentifierType || '4',
        ResultURL: config.mpesa.reversalResultUrl || config.mpesa.resultUrl,
        QueueTimeOutURL: config.mpesa.queueTimeoutUrl,
        Remarks: remarks || 'Transaction Reversal',
        Occasion: occasion || ''
      };

      const response = await axios.post(mpesaUrls.reversal, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data;
    } catch (error) {
      logger.error('Reversal error:', error.message);
      throw error;
    }
  }
}

module.exports = new MpesaService();