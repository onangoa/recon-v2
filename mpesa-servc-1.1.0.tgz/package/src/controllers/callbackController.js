const logger = require('../utils/logger');

class CallbackController {
  async handleStkPushCallback(req, res) {
    try {
      const { Body } = req.body;

      if (Body.stkCallback.ResultCode === 0) {
        const { MerchantRequestID, CheckoutRequestID, ResultCode, ResultDesc } = Body.stkCallback;
        const metadata = Body.stkCallback.CallbackMetadata.Item;

        const amount = metadata.find(item => item.Name === 'Amount').Value;
        const mpesaReceiptNumber = metadata.find(item => item.Name === 'MpesaReceiptNumber').Value;
        const transactionDate = metadata.find(item => item.Name === 'TransactionDate').Value;
        const phoneNumber = metadata.find(item => item.Name === 'PhoneNumber').Value;

        logger.info('STK Push successful:', {
          MerchantRequestID,
          CheckoutRequestID,
          amount,
          mpesaReceiptNumber,
          transactionDate,
          phoneNumber
        });

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success',
          ThirdPartyTransID: MerchantRequestID
        });
      } else {
        const { MerchantRequestID, CheckoutRequestID, ResultCode, ResultDesc } = Body.stkCallback;

        logger.error('STK Push failed:', {
          MerchantRequestID,
          CheckoutRequestID,
          ResultCode,
          ResultDesc
        });

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed',
          ThirdPartyTransID: MerchantRequestID
        });
      }
    } catch (error) {
      logger.error('STK Push callback error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Callback processing failed'
      });
    }
  }

  async handleC2BConfirmation(req, res) {
    try {
      const { TransactionType, TransID, TransTime, TransAmount, BusinessShortCode, 
              BillRefNumber, InvoiceNumber, OrgAccountBalance, ThirdPartyTransID, 
              MSISDN, FirstName, MiddleName, LastName } = req.body;

      logger.info('C2B Confirmation received:', {
        TransactionType,
        TransID,
        TransAmount,
        BusinessShortCode,
        MSISDN,
        BillRefNumber
      });

      res.json({
        ResultCode: 0,
        ResultDesc: 'Confirmation received successfully'
      });
    } catch (error) {
      logger.error('C2B confirmation error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Confirmation processing failed'
      });
    }
  }

  async handleC2BValidation(req, res) {
    try {
      const { TransactionType, TransID, TransTime, TransAmount, BusinessShortCode, 
              BillRefNumber, InvoiceNumber, MSISDN, FirstName, LastName } = req.body;

      logger.info('C2B Validation received:', {
        TransactionType,
        TransID,
        TransAmount,
        BusinessShortCode,
        MSISDN,
        BillRefNumber
      });

      res.json({
        ResultCode: 0,
        ResultDesc: 'Service request is processed successfully'
      });
    } catch (error) {
      logger.error('C2B validation error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Service request is processed failed'
      });
    }
  }

  async handleB2CResult(req, res) {
    try {
      const { Result } = req.body;

      if (Result.ResultCode === 0) {
        const { ResultType, ResultCode, ResultDesc, OriginatorConversationID,
                ConversationID, TransactionID } = Result;

        logger.info('B2C Result successful:', {
          ResultType,
          OriginatorConversationID,
          TransactionID,
          ConversationID
        });

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('B2C Result failed:', Result);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('B2C result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleB2BResult(req, res) {
    try {
      logger.info('B2B Callback received, full body:', JSON.stringify(req.body));
      
      const { Result } = req.body;

      if (!Result) {
        logger.error('B2B callback missing Result object in request body');
        return res.json({
          ResultCode: 1,
          ResultDesc: 'Invalid callback format - missing Result'
        });
      }

      if (Result.ResultCode === 0) {
        const { ResultType, ResultCode, ResultDesc, OriginatorConversationID,
                ConversationID, TransactionID } = Result;

        logger.info(`B2B Result successful: ResultType=${ResultType}, OriginatorConversationID=${OriginatorConversationID}, TransactionID=${TransactionID}, ConversationID=${ConversationID}`);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('B2B Result failed:', Result);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('B2B result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleB2PochiResult(req, res) {
    try {
      const { Result } = req.body;

      if (Result.ResultCode === 0) {
        const { ResultType, ResultCode, ResultDesc, OriginatorConversationID,
                ConversationID, TransactionID } = Result;

        logger.info(`B2Pochi Result successful: ResultType=${ResultType}, OriginatorConversationID=${OriginatorConversationID}, TransactionID=${TransactionID}, ConversationID=${ConversationID}`);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('B2Pochi Result failed:', Result);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('B2Pochi result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleAccountBalanceResult(req, res) {
    try {
      const { Result } = req.body;

      if (Result.ResultCode === 0) {
        const { OriginatorConversationID, ResultCode, ResultDesc, ResultParameters, ConversationID } = Result;
        logger.info('Account Balance Result:', ResultParameters);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('Account Balance Result failed:', Result);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('Account balance result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleTransactionStatusResult(req, res) {
    try {
      const { Result } = req.body;

      if (Result.ResultCode === 0) {
        const { OriginatorConversationID, ResultCode, ResultDesc, TransactionID, ConversationID } = Result;
        logger.info('Transaction Status Result:', Result);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('Transaction Status Result failed:', Result);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('Transaction status result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleReversalResult(req, res) {
    try {
      const { Result } = req.body;

      if (Result.ResultCode === 0) {
        const { OriginatorConversationID, ResultCode, ResultDesc, TransactionID, ConversationID } = Result;
        logger.info('Reversal Result:', Result);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('Reversal Result failed:', Result);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('Reversal result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleTimeout(req, res) {
    try {
      logger.info('Timeout callback received:', req.body);

      res.json({
        ResultCode: 0,
        ResultDesc: 'Timeout received'
      });
    } catch (error) {
      logger.error('Timeout callback error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Timeout processing failed'
      });
    }
  }
}

module.exports = new CallbackController();