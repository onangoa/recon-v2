const logger = require('../utils/logger');
const { getModels } = require('../database/db');

class CallbackController {
  async handleStkPushCallback(req, res) {
    try {
      const Transaction = getModels().Transaction;
      const { Body } = req.body;

      if (Body.stkCallback.ResultCode === 0) {
        const { MerchantRequestID, CheckoutRequestID, ResultCode, ResultDesc } = Body.stkCallback;
        const metadata = Body.stkCallback.CallbackMetadata.Item;

        const amount = metadata.find(item => item.Name === 'Amount').Value;
        const mpesaReceiptNumber = metadata.find(item => item.Name === 'MpesaReceiptNumber').Value;
        const transactionDate = metadata.find(item => item.Name === 'TransactionDate').Value;
        const phoneNumber = metadata.find(item => item.Name === 'PhoneNumber').Value;

        logger.info('STK Push successful:', {
          MerchantRequestID,
          CheckoutRequestID,
          amount,
          mpesaReceiptNumber,
          transactionDate,
          phoneNumber
        });

        logger.info('Attempting to update STK Push transaction with checkoutRequestId:', CheckoutRequestID);

        const [updatedCount] = await Transaction.update({
          status: 'SUCCESS',
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          mpesaReceiptNumber,
          rawCallbackData: req.body
        }, {
          where: { checkoutRequestId: CheckoutRequestID }
        });

        logger.info(`STK Push transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success',
          ThirdPartyTransID: MerchantRequestID
        });
      } else {
        const { MerchantRequestID, CheckoutRequestID, ResultCode, ResultDesc } = Body.stkCallback;

        logger.error('STK Push failed:', {
          MerchantRequestID,
          CheckoutRequestID,
          ResultCode,
          ResultDesc
        });

        logger.info('Attempting to update failed STK Push transaction with checkoutRequestId:', CheckoutRequestID);

        const [updatedCount] = await Transaction.update({
          status: ResultCode === 1032 ? 'CANCELLED' : 'FAILED',
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { checkoutRequestId: CheckoutRequestID }
        });

        logger.info(`STK Push transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed',
          ThirdPartyTransID: MerchantRequestID
        });
      }
    } catch (error) {
      logger.error('STK Push callback error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Callback processing failed'
      });
    }
  }

  async handleC2BConfirmation(req, res) {
    try {
      const Transaction = getModels().Transaction;
      const { TransactionType, TransID, TransTime, TransAmount, BusinessShortCode, 
              BillRefNumber, InvoiceNumber, OrgAccountBalance, ThirdPartyTransID, 
              MSISDN, FirstName, MiddleName, LastName } = req.body;

      logger.info('C2B Confirmation received:', {
        TransactionType,
        TransID,
        TransAmount,
        BusinessShortCode,
        MSISDN,
        BillRefNumber
      });

      // Save C2B transaction to DB
      await Transaction.create({
        transactionId: TransID,
        amount: parseFloat(TransAmount),
        phoneNumber: MSISDN,
        transactionType: 'C2B',
        status: 'SUCCESS',
        accountReference: BillRefNumber,
        mpesaReceiptNumber: TransID,
        rawCallbackData: req.body
      });

      res.json({
        ResultCode: 0,
        ResultDesc: 'Confirmation received successfully'
      });
    } catch (error) {
      logger.error('C2B confirmation error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Confirmation processing failed'
      });
    }
  }

  async handleC2BValidation(req, res) {
    try {
      const { TransactionType, TransID, TransTime, TransAmount, BusinessShortCode, 
              BillRefNumber, InvoiceNumber, MSISDN, FirstName, LastName } = req.body;

      logger.info('C2B Validation received:', {
        TransactionType,
        TransID,
        TransAmount,
        BusinessShortCode,
        MSISDN,
        BillRefNumber
      });

      res.json({
        ResultCode: 0,
        ResultDesc: 'Service request is processed successfully'
      });
    } catch (error) {
      logger.error('C2B validation error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Service request is processed failed'
      });
    }
  }

  async handleB2CResult(req, res) {
    try {
      const Transaction = getModels().Transaction;
      const { Result } = req.body;

      if (Result.ResultCode === 0) {
        const { ResultType, ResultCode, ResultDesc, OriginatorConversationID,
                ConversationID, TransactionID } = Result;

        logger.info('B2C Result successful:', {
          ResultType,
          OriginatorConversationID,
          TransactionID,
          ConversationID
        });

        logger.info(`Attempting to update B2C transaction with conversationId: ${ConversationID}`);

        const [updatedCount] = await Transaction.update({
          status: 'SUCCESS',
          transactionId: TransactionID,
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`B2C Transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('B2C Result failed:', Result);

        const [updatedCount] = await Transaction.update({
          status: 'FAILED',
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`B2C Transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('B2C result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleB2BResult(req, res) {
    try {
      const Transaction = getModels().Transaction;
      logger.info('B2B Callback received, full body:', JSON.stringify(req.body));
      
      const { Result } = req.body;

      if (!Result) {
        logger.error('B2B callback missing Result object in request body');
        return res.json({
          ResultCode: 1,
          ResultDesc: 'Invalid callback format - missing Result'
        });
      }

      if (Result.ResultCode === 0) {
        const { ResultType, ResultCode, ResultDesc, OriginatorConversationID,
                ConversationID, TransactionID } = Result;

        logger.info(`B2B Result successful: ResultType=${ResultType}, OriginatorConversationID=${OriginatorConversationID}, TransactionID=${TransactionID}, ConversationID=${ConversationID}`);

        logger.info(`Attempting to update B2B transaction with conversationId: ${ConversationID}`);

        if (!ConversationID) {
          logger.error('ConversationID is missing from B2B callback');
          return res.json({
            ResultCode: 1,
            ResultDesc: 'Missing ConversationID'
          });
        }

        const [updatedCount] = await Transaction.update({
          status: 'SUCCESS',
          transactionId: TransactionID,
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`B2B Transaction update result: ${updatedCount} rows updated`);

        if (updatedCount === 0) {
          logger.error(`No transaction found with conversationId: ${ConversationID}`);
          
          // Try to find any B2B transactions for debugging
          const b2bTransactions = await Transaction.findAll({
            where: {
              transactionType: 'B2B'
            },
            limit: 5,
            order: [['createdAt', 'DESC']]
          });
          
          logger.info('Recent B2B transactions in database:', JSON.stringify(b2bTransactions.map(t => ({
            id: t.id,
            originatorConversationId: t.originatorConversationId,
            conversationId: t.conversationId,
            status: t.status,
            amount: t.amount,
            createdAt: t.createdAt
          }))));
        }

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('B2B Result failed:', Result);

        logger.info(`Attempting to update failed B2B transaction with conversationId: ${ConversationID}`);

        const [updatedCount] = await Transaction.update({
          status: 'FAILED',
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`B2B Transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('B2B result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleB2PochiResult(req, res) {
    try {
      const Transaction = getModels().Transaction;
      const { Result } = req.body;

      if (Result.ResultCode === 0) {
        const { ResultType, ResultCode, ResultDesc, OriginatorConversationID,
                ConversationID, TransactionID } = Result;

        logger.info(`B2Pochi Result successful: ResultType=${ResultType}, OriginatorConversationID=${OriginatorConversationID}, TransactionID=${TransactionID}, ConversationID=${ConversationID}`);

        logger.info(`Attempting to update B2Pochi transaction with conversationId: ${ConversationID}`);

        const [updatedCount] = await Transaction.update({
          status: 'SUCCESS',
          transactionId: TransactionID,
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`B2Pochi Transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('B2Pochi Result failed:', Result);

        logger.info(`Attempting to update failed B2Pochi transaction with conversationId: ${ConversationID}`);

        const [updatedCount] = await Transaction.update({
          status: 'FAILED',
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`B2Pochi Transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('B2Pochi result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleAccountBalanceResult(req, res) {
    try {
      const Transaction = getModels().Transaction;
      const { Result } = req.body;

      if (Result.ResultCode === 0) {
        const { OriginatorConversationID, ResultCode, ResultDesc, ResultParameters, ConversationID } = Result;
        logger.info('Account Balance Result:', ResultParameters);

        logger.info(`Attempting to update account balance transaction with conversationId: ${ConversationID}`);

        const [updatedCount] = await Transaction.update({
          status: 'SUCCESS',
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`Account balance transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('Account Balance Result failed:', Result);

        const [updatedCount] = await Transaction.update({
          status: 'FAILED',
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`Account balance transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('Account balance result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleTransactionStatusResult(req, res) {
    try {
      const Transaction = getModels().Transaction;
      const { Result } = req.body;

      if (Result.ResultCode === 0) {
        const { OriginatorConversationID, ResultCode, ResultDesc, TransactionID, ConversationID } = Result;
        logger.info('Transaction Status Result:', Result);

        logger.info(`Attempting to update transaction status with conversationId: ${ConversationID}`);

        const [updatedCount] = await Transaction.update({
          status: 'SUCCESS',
          transactionId: TransactionID,
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`Transaction status update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('Transaction Status Result failed:', Result);

        const [updatedCount] = await Transaction.update({
          status: 'FAILED',
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`Transaction status update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('Transaction status result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleReversalResult(req, res) {
    try {
      const Transaction = getModels().Transaction;
      const { Result } = req.body;

      if (Result.ResultCode === 0) {
        const { OriginatorConversationID, ResultCode, ResultDesc, TransactionID, ConversationID } = Result;
        logger.info('Reversal Result:', Result);

        logger.info(`Attempting to update reversal transaction with conversationId: ${ConversationID}`);

        const [updatedCount] = await Transaction.update({
          status: 'SUCCESS',
          transactionId: TransactionID,
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`Reversal transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 0,
          ResultDesc: 'Success'
        });
      } else {
        const { OriginatorConversationID, ResultCode, ResultDesc, ConversationID } = Result;
        logger.error('Reversal Result failed:', Result);

        const [updatedCount] = await Transaction.update({
          status: 'FAILED',
          originatorConversationId: OriginatorConversationID,
          resultCode: ResultCode,
          resultDesc: ResultDesc,
          rawCallbackData: req.body
        }, {
          where: { conversationId: ConversationID }
        });

        logger.info(`Reversal transaction update result: ${updatedCount} rows updated`);

        res.json({
          ResultCode: 1,
          ResultDesc: 'Failed'
        });
      }
    } catch (error) {
      logger.error('Reversal result error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Result processing failed'
      });
    }
  }

  async handleTimeout(req, res) {
    try {
      logger.info('Timeout callback received:', req.body);

      res.json({
        ResultCode: 0,
        ResultDesc: 'Timeout received'
      });
    } catch (error) {
      logger.error('Timeout callback error:', error);
      res.json({
        ResultCode: 1,
        ResultDesc: 'Timeout processing failed'
      });
    }
  }
}

module.exports = new CallbackController();