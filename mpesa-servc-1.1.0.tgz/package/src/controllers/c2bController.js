const mpesaService = require('../services/mpesaService');
const logger = require('../utils/logger');

class C2BController {
  async registerUrls(req, res) {
    try {
      const { shortCode, validationURL, confirmationURL, responseType } = req.body;

      const validResponseTypes = ['Completed', 'Cancelled'];
      if (responseType && !validResponseTypes.includes(responseType)) {
        return res.status(400).json({
          success: false,
          message: `Invalid ResponseType. Valid values are: ${validResponseTypes.join(', ')}`
        });
      }

      const result = await mpesaService.c2bRegister({
        shortCode,
        validationURL,
        confirmationURL,
        responseType: responseType || 'Completed'
      });

      res.json({
        success: true,
        message: 'C2B URLs registered successfully',
        data: result
      });
    } catch (error) {
      logger.error('C2B URL registration error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to register C2B URLs',
        error: error.message
      });
    }
  }

  async simulateC2B(req, res) {
    try {
      const { shortCode, commandID, amount, msisdn, billRefNumber } = req.body;

      if (!shortCode || !commandID || !amount || !msisdn) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: shortCode, commandID, amount, msisdn'
        });
      }

      const validCommandIDs = ['CustomerBuyGoodsOnline', 'CustomerPayBillOnline'];
      if (!validCommandIDs.includes(commandID)) {
        return res.status(400).json({
          success: false,
          message: `Invalid CommandID. Valid values are: ${validCommandIDs.join(', ')}`
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.c2bSimulate({
        shortCode,
        commandID,
        amount,
        msisdn,
        billRefNumber: billRefNumber || ''
      });

      res.json({
        success: true,
        message: 'C2B payment simulated successfully',
        data: result
      });
    } catch (error) {
      logger.error('C2B simulation error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to simulate C2B payment',
        error: error.message
      });
    }
  }

  async customerBuyGoods(req, res) {
    try {
      const { shortCode, amount, msisdn } = req.body;

      if (!shortCode || !amount || !msisdn) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: shortCode, amount, msisdn'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.c2bSimulate({
        shortCode,
        commandID: 'CustomerBuyGoodsOnline',
        amount,
        msisdn,
        billRefNumber: ''
      });

      res.json({
        success: true,
        message: 'Customer Buy Goods payment simulated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Customer Buy Goods simulation error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to simulate Customer Buy Goods payment',
        error: error.message
      });
    }
  }

  async customerPayBill(req, res) {
    try {
      const { shortCode, amount, msisdn, billRefNumber } = req.body;

      if (!shortCode || !amount || !msisdn) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: shortCode, amount, msisdn'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.c2bSimulate({
        shortCode,
        commandID: 'CustomerPayBillOnline',
        amount,
        msisdn,
        billRefNumber: billRefNumber || ''
      });

      res.json({
        success: true,
        message: 'Customer Pay Bill payment simulated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Customer Pay Bill simulation error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to simulate Customer Pay Bill payment',
        error: error.message
      });
    }
  }
}

module.exports = new C2BController();