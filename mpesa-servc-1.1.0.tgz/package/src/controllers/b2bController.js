const mpesaService = require('../services/mpesaService');
const logger = require('../utils/logger');
const MpesaEncryption = require('../utils/mpesaEncryption');

class B2BController {
  async businessPayBill(req, res) {
    try {
      const {
        initiatorName,
        securityCredential,
        amount,
        partyA,
        partyB,
        accountReference,
        remarks,
        requester,
        occasion,
        senderIdentifierType,
        receiverIdentifierType
      } = req.body;

      if (!amount || !partyA || !partyB || !accountReference) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: amount, partyA, partyB, accountReference'
        });
      }

      const result = await mpesaService.b2b({
        commandID: 'BusinessPayBill',
        senderIdentifierType,
        receiverIdentifierType,
        amount,
        partyA,
        partyB,
        accountReference,
        remarks,
        requester,
        occasion,
        initiatorName,
        securityCredential
      });

      res.json({
        success: true,
        message: 'Business Pay Bill initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Business Pay Bill error:', error);
      res.status(500).json({
        success: false,
        message: 'Business Pay Bill failed',
        error: error.message
      });
    }
  }

  async businessBuyGoods(req, res) {
    try {
      const {
        initiatorName,
        securityCredential,
        amount,
        partyA,
        partyB,
        accountReference,
        remarks,
        requester,
        occasion
      } = req.body;

      if (!amount || !partyA || !partyB || !accountReference) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: amount, partyA, partyB, accountReference'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.b2b({
        commandID: 'BusinessBuyGoods',
        senderIdentifierType: '4',
        receiverIdentifierType: '4',
        amount,
        partyA,
        partyB,
        accountReference,
        remarks: remarks || 'Business Buy Goods',
        requester,
        occasion,
        initiatorName,
        securityCredential
      });

      res.json({
        success: true,
        message: 'Business Buy Goods initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Business Buy Goods error:', error);
      res.status(500).json({
        success: false,
        message: 'Business Buy Goods failed',
        error: error.message
      });
    }
  }

  async b2bTransfer(req, res) {
    try {
      const {
        initiatorName,
        securityCredential,
        commandID,
        senderIdentifierType,
        receiverIdentifierType,
        amount,
        partyA,
        partyB,
        accountReference,
        remarks,
        requester,
        occasion
      } = req.body;

      if (!commandID || !senderIdentifierType || !receiverIdentifierType || 
          !amount || !partyA || !partyB || !accountReference) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: commandID, senderIdentifierType, receiverIdentifierType, amount, partyA, partyB, accountReference'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.b2b({
        initiatorName,
        securityCredential,
        commandID,
        senderIdentifierType,
        receiverIdentifierType,
        amount,
        partyA,
        partyB,
        accountReference,
        remarks: remarks || 'B2B Payment',
        requester,
        occasion
      });

      res.json({
        success: true,
        message: 'B2B transfer initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('B2B transfer error:', error);
      res.status(500).json({
        success: false,
        message: 'B2B transfer failed',
        error: error.message
      });
    }
  }
}

module.exports = new B2BController();