const mpesaService = require('../services/mpesaService');
const logger = require('../utils/logger');
const MpesaEncryption = require('../utils/mpesaEncryption');

class B2CController {
  async b2cPayment(req, res) {
    try {
      const {
        initiatorName,
        securityCredential,
        commandID,
        amount,
        partyA,
        partyB,
        remarks,
        occasion
      } = req.body;

      if (!amount || !partyB) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: amount, partyB'
        });
      }

      if (!MpesaEncryption.validatePhoneFormat(partyB)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const validCommandIDs = ['SalaryPayment', 'BusinessPayment', 'PromotionPayment'];
      if (commandID && !validCommandIDs.includes(commandID)) {
        return res.status(400).json({
          success: false,
          message: `Invalid CommandID. Valid values are: ${validCommandIDs.join(', ')}`
        });
      }

      const result = await mpesaService.b2c({
        initiatorName,
        securityCredential,
        commandID: commandID || 'BusinessPayment',
        amount,
        partyA,
        partyB,
        remarks: remarks || 'B2C Payment',
        occasion
      });

      res.json({
        success: true,
        message: 'B2C payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('B2C payment error:', error);
      res.status(500).json({
        success: false,
        message: 'B2C payment failed',
        error: error.message
      });
    }
  }

  async salaryPayment(req, res) {
    try {
      const {
        initiatorName,
        securityCredential,
        amount,
        partyA,
        partyB,
        remarks,
        occasion
      } = req.body;

      if (!amount || !partyB) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: amount, partyB'
        });
      }

      const formattedPhone = MpesaEncryption.formatPhoneNumber(partyB);
      
      if (!MpesaEncryption.validatePhoneFormat(formattedPhone)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.b2c({
        initiatorName,
        securityCredential,
        commandID: 'SalaryPayment',
        amount,
        partyA,
        partyB: formattedPhone,
        remarks: remarks || 'Salary Payment',
        occasion
      });

      res.json({
        success: true,
        message: 'Salary payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Salary payment error:', error);
      res.status(500).json({
        success: false,
        message: 'Salary payment failed',
        error: error.message
      });
    }
  }

  async businessPayment(req, res) {
    try {
      const {
        initiatorName,
        securityCredential,
        amount,
        partyA,
        partyB,
        remarks,
        occasion
      } = req.body;

      if (!amount || !partyB) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: amount, partyB'
        });
      }

      const formattedPhone = MpesaEncryption.formatPhoneNumber(partyB);
      
      if (!MpesaEncryption.validatePhoneFormat(formattedPhone)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.b2c({
        initiatorName,
        securityCredential,
        commandID: 'BusinessPayment',
        amount,
        partyA,
        partyB: formattedPhone,
        remarks: remarks || 'Business Payment',
        occasion
      });

      res.json({
        success: true,
        message: 'Business payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Business payment error:', error);
      res.status(500).json({
        success: false,
        message: 'Business payment failed',
        error: error.message
      });
    }
  }

  async promotionPayment(req, res) {
    try {
      const {
        initiatorName,
        securityCredential,
        amount,
        partyA,
        partyB,
        remarks,
        occasion
      } = req.body;

      if (!amount || !partyB) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: amount, partyB'
        });
      }

      const formattedPhone = MpesaEncryption.formatPhoneNumber(partyB);
      
      if (!MpesaEncryption.validatePhoneFormat(formattedPhone)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.b2c({
        initiatorName,
        securityCredential,
        commandID: 'PromotionPayment',
        amount,
        partyA,
        partyB: formattedPhone,
        remarks: remarks || 'Promotional Payment',
        occasion
      });

      res.json({
        success: true,
        message: 'Promotional payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Promotional payment error:', error);
      res.status(500).json({
        success: false,
        message: 'Promotional payment failed',
        error: error.message
      });
    }
  }
}

module.exports = new B2CController();