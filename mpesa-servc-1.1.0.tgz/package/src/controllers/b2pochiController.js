const mpesaService = require('../services/mpesaService');
const logger = require('../utils/logger');
const MpesaEncryption = require('../utils/mpesaEncryption');

class B2PochiController {
  async b2pochiPayment(req, res) {
    try {
      const {
        initiatorName,
        securityCredential,
        amount,
        partyA,
        partyB,
        remarks,
        occasion
      } = req.body;

      if (!amount || !partyB) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: amount, partyB'
        });
      }

      if (!MpesaEncryption.validatePhoneFormat(partyB)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.b2pochi({
        initiatorName,
        securityCredential,
        amount,
        partyA,
        partyB,
        remarks: remarks || 'B2Pochi Payment',
        occasion
      });

      res.json({
        success: true,
        message: 'B2Pochi payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('B2Pochi payment error:', error);
      res.status(500).json({
        success: false,
        message: 'B2Pochi payment failed',
        error: error.message
      });
    }
  }
}

module.exports = new B2PochiController();