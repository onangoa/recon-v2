const mpesaService = require('../services/mpesaService');
const logger = require('../utils/logger');
const MpesaEncryption = require('../utils/mpesaEncryption');
const Transaction = require('../database/models/Transaction');

class TransactionController {
  async getLocalTransactions(req, res) {
    try {
      const { limit = 10, offset = 0, status, transactionType } = req.query;
      const where = {};
      
      if (status) where.status = status;
      if (transactionType) where.transactionType = transactionType;

      const transactions = await Transaction.findAndCountAll({
        where,
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [['createdAt', 'DESC']]
      });

      res.json({
        success: true,
        data: transactions.rows,
        total: transactions.count,
        limit: parseInt(limit),
        offset: parseInt(offset)
      });
    } catch (error) {
      logger.error('Error fetching local transactions:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch local transactions',
        error: error.message
      });
    }
  }

  async getLocalTransactionById(req, res) {
    try {
      const { id } = req.params;
      const transaction = await Transaction.findByPk(id);

      if (!transaction) {
        return res.status(404).json({
          success: false,
          message: 'Transaction not found'
        });
      }

      res.json({
        success: true,
        data: transaction
      });
    } catch (error) {
      logger.error('Error fetching local transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch local transaction',
        error: error.message
      });
    }
  }

  async checkTransactionStatus(req, res) {
    try {
      const { transactionID, originalConversationID, partyA, identifierType, remarks, occasion } = req.body;

      if (!transactionID) {
        return res.status(400).json({
          success: false,
          message: 'Missing required field: transactionID'
        });
      }

      const result = await mpesaService.transactionStatus({
        transactionID,
        originalConversationID,
        partyA,
        identifierType: identifierType || '4',
        remarks,
        occasion
      });

      res.json({
        success: true,
        data: result
      });
    } catch (error) {
      logger.error('Transaction status check error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to check transaction status',
        error: error.message
      });
    }
  }

  async checkAccountBalance(req, res) {
    try {
      const { partyA, identifierType, remarks } = req.body;

      const result = await mpesaService.accountBalance({
        partyA,
        identifierType: identifierType || '4',
        remarks
      });

      res.json({
        success: true,
        data: result
      });
    } catch (error) {
      logger.error('Account balance check error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to check account balance',
        error: error.message
      });
    }
  }

  async reverseTransaction(req, res) {
    try {
      const {
        initiatorName,
        securityCredential,
        transactionID,
        amount,
        receiverParty,
        receiverIdentifierType,
        remarks,
        occasion
      } = req.body;

      if (!transactionID || !amount) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: transactionID, amount'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.reversal({
        initiatorName,
        securityCredential,
        transactionID,
        amount,
        receiverParty,
        receiverIdentifierType: receiverIdentifierType || '4',
        remarks: remarks || 'Transaction Reversal',
        occasion
      });

      res.json({
        success: true,
        message: 'Transaction reversal initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Transaction reversal error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to reverse transaction',
        error: error.message
      });
    }
  }

  async queryTransactionByReceipt(req, res) {
    try {
      const { transactionID, partyA, remarks, occasion } = req.body;

      if (!transactionID) {
        return res.status(400).json({
          success: false,
          message: 'Missing required field: transactionID'
        });
      }

      const result = await mpesaService.transactionStatus({
        transactionID,
        partyA: partyA || config.mpesa.shortCode,
        identifierType: '4',
        remarks: remarks || 'Query by receipt',
        occasion
      });

      res.json({
        success: true,
        message: 'Transaction query initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Transaction query error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to query transaction',
        error: error.message
      });
    }
  }

  async queryTransactionByOriginatorID(req, res) {
    try {
      const { originalConversationID, partyA, remarks, occasion } = req.body;

      if (!originalConversationID) {
        return res.status(400).json({
          success: false,
          message: 'Missing required field: originalConversationID'
        });
      }

      const result = await mpesaService.transactionStatus({
        transactionID: '', 
        originalConversationID,
        partyA: partyA || config.mpesa.shortCode,
        identifierType: '4',
        remarks: remarks || 'Query by originator ID',
        occasion
      });

      res.json({
        success: true,
        message: 'Transaction query initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Transaction query error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to query transaction',
        error: error.message
      });
    }
  }
}

module.exports = new TransactionController();