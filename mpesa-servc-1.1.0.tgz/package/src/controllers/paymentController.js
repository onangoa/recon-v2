const mpesaService = require('../services/mpesaService');
const logger = require('../utils/logger');
const MpesaEncryption = require('../utils/mpesaEncryption');

class PaymentController {
  async phonePayment(req, res) {
    try {
      const { phoneNumber, amount, accountReference, transactionDesc, callbackURL } = req.body;

      if (!phoneNumber || !amount || !accountReference) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: phoneNumber, amount, accountReference'
        });
      }

      const formattedPhone = MpesaEncryption.formatPhoneNumber(phoneNumber);
      
      if (!MpesaEncryption.validatePhoneFormat(formattedPhone)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.stkPush({
        phoneNumber: formattedPhone,
        amount,
        accountReference,
        transactionDesc,
        callbackURL
      });

      res.json({
        success: true,
        message: 'Phone payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Phone payment error:', error);
      res.status(500).json({
        success: false,
        message: 'Phone payment failed',
        error: error.message
      });
    }
  }

  async pochiPayment(req, res) {
    try {
      const { phoneNumber, amount, accountReference, transactionDesc, callbackURL } = req.body;

      if (!phoneNumber || !amount || !accountReference) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: phoneNumber, amount, accountReference'
        });
      }

      const formattedPhone = MpesaEncryption.formatPhoneNumber(phoneNumber);
      
      if (!MpesaEncryption.validatePhoneFormat(formattedPhone)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.stkPush({
        phoneNumber: formattedPhone,
        amount,
        accountReference: `POCHI-${accountReference}`,
        transactionDesc: transactionDesc || 'Pochi La Biashara Payment',
        callbackURL
      });

      res.json({
        success: true,
        message: 'Pochi payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Pochi payment error:', error);
      res.status(500).json({
        success: false,
        message: 'Pochi payment failed',
        error: error.message
      });
    }
  }

  async tillPayment(req, res) {
    try {
      const { phoneNumber, amount, tillNumber, accountReference, transactionDesc, callbackURL } = req.body;

      if (!phoneNumber || !amount || !tillNumber || !accountReference) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: phoneNumber, amount, tillNumber, accountReference'
        });
      }

      const formattedPhone = MpesaEncryption.formatPhoneNumber(phoneNumber);
      
      if (!MpesaEncryption.validatePhoneFormat(formattedPhone)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.stkPush({
        phoneNumber: formattedPhone,
        amount,
        accountReference: `${tillNumber}-${accountReference}`,
        transactionDesc: transactionDesc || 'Till Number Payment',
        callbackURL
      });

      res.json({
        success: true,
        message: 'Till payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Till payment error:', error);
      res.status(500).json({
        success: false,
        message: 'Till payment failed',
        error: error.message
      });
    }
  }

  async paybillPayment(req, res) {
    try {
      const { phoneNumber, amount, paybillNumber, accountNumber, transactionDesc, callbackURL } = req.body;

      if (!phoneNumber || !amount || !paybillNumber || !accountNumber) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: phoneNumber, amount, paybillNumber, accountNumber'
        });
      }

      const formattedPhone = MpesaEncryption.formatPhoneNumber(phoneNumber);
      
      if (!MpesaEncryption.validatePhoneFormat(formattedPhone)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.stkPush({
        phoneNumber: formattedPhone,
        amount,
        accountReference: `${paybillNumber}-${accountNumber}`,
        transactionDesc: transactionDesc || 'Paybill Payment',
        callbackURL
      });

      res.json({
        success: true,
        message: 'Paybill payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Paybill payment error:', error);
      res.status(500).json({
        success: false,
        message: 'Paybill payment failed',
        error: error.message
      });
    }
  }

  async customerBuyGoodsOnline(req, res) {
    try {
      const { phoneNumber, amount, tillNumber, accountReference, transactionDesc, callbackURL } = req.body;

      if (!phoneNumber || !amount || !tillNumber) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: phoneNumber, amount, tillNumber'
        });
      }

      const formattedPhone = MpesaEncryption.formatPhoneNumber(phoneNumber);
      
      if (!MpesaEncryption.validatePhoneFormat(formattedPhone)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.stkPush({
        phoneNumber: formattedPhone,
        amount,
        accountReference: accountReference || tillNumber,
        transactionDesc: transactionDesc || 'Customer Buy Goods Online',
        callbackURL
      });

      res.json({
        success: true,
        message: 'Customer Buy Goods Online payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Customer Buy Goods Online error:', error);
      res.status(500).json({
        success: false,
        message: 'Customer Buy Goods Online payment failed',
        error: error.message
      });
    }
  }

  async customerPayBillOnline(req, res) {
    try {
      const { phoneNumber, amount, paybillNumber, accountNumber, transactionDesc, callbackURL } = req.body;

      if (!phoneNumber || !amount || !paybillNumber || !accountNumber) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: phoneNumber, amount, paybillNumber, accountNumber'
        });
      }

      const formattedPhone = MpesaEncryption.formatPhoneNumber(phoneNumber);
      
      if (!MpesaEncryption.validatePhoneFormat(formattedPhone)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Use format: 2547XXXXXXXX'
        });
      }

      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Amount must be a positive number'
        });
      }

      const result = await mpesaService.stkPush({
        phoneNumber: formattedPhone,
        amount,
        accountReference: `${paybillNumber}-${accountNumber}`,
        transactionDesc: transactionDesc || 'Customer Pay Bill Online',
        callbackURL
      });

      res.json({
        success: true,
        message: 'Customer Pay Bill Online payment initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('Customer Pay Bill Online error:', error);
      res.status(500).json({
        success: false,
        message: 'Customer Pay Bill Online payment failed',
        error: error.message
      });
    }
  }
}

module.exports = new PaymentController();