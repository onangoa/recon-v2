const mpesaService = require('../services/mpesaService');
const logger = require('../utils/logger');

class StkPushController {
  async initiateStkPush(req, res) {
    try {
      const { phoneNumber, amount, accountReference, transactionDesc, callbackURL } = req.body;

      if (!phoneNumber || !amount || !accountReference) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: phoneNumber, amount, accountReference'
        });
      }

      const result = await mpesaService.stkPush({
        phoneNumber,
        amount,
        accountReference,
        transactionDesc,
        callbackURL
      });

      res.json({
        success: true,
        message: 'STK Push initiated successfully',
        data: result
      });
    } catch (error) {
      logger.error('STK Push initiation error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to initiate STK Push',
        error: error.message
      });
    }
  }

  async queryStkPush(req, res) {
    try {
      const { checkoutRequestID } = req.params;

      if (!checkoutRequestID) {
        return res.status(400).json({
          success: false,
          message: 'Missing checkoutRequestID'
        });
      }

      const result = await mpesaService.queryStkPush(checkoutRequestID);

      res.json({
        success: true,
        data: result
      });
    } catch (error) {
      logger.error('STK Push query error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to query STK Push',
        error: error.message
      });
    }
  }
}

module.exports = new StkPushController();