const { Sequelize } = require('sequelize');
const config = require('../config/config');
const logger = require('../utils/logger');

let sequelize = null;
let Transaction = null;
let dbInitialized = false;

const initModels = (sequelizeInstance) => {
  const TransactionModel = require('./models/Transaction');
  Transaction = TransactionModel(sequelizeInstance);
  logger.info('Transaction model initialized successfully');
  return { Transaction };
};

const connectDB = async (externalSequelize = null) => {
  try {
    if (externalSequelize) {
      sequelize = externalSequelize;
      logger.info('Using provided Sequelize instance.');
    } else if (!sequelize) {
      const dbConfig = { ...config.database };

      if (dbConfig.dialect === 'sqlite') {
        try {
          require('sqlite3');
        } catch (error) {
          throw new Error('sqlite3 package is required for SQLite databases. Please install it manually: npm install sqlite3');
        }
      }

      sequelize = new Sequelize(dbConfig);
      logger.info('Creating new Sequelize instance.');
    }

    await sequelize.authenticate();
    logger.info('Database connection has been established successfully.');

    if (!Transaction) {
      initModels(sequelize);
    }

    const queryInterface = sequelize.getQueryInterface();
    const tables = await queryInterface.showAllTables();

    const tableExists = tables.some(table =>
      table.toLowerCase() === 'mpesa_transactions'
    );

    if (!tableExists) {
      logger.info('M-Pesa transaction table not found. Synchronizing database...');
      await sequelize.sync({ alter: true });
      logger.info('Database models synchronized.');
    } else {
      logger.info('Database tables already exist. Skipping synchronization.');
    }

    dbInitialized = true;
    logger.info(`Database initialization complete. Transaction model is ${Transaction ? 'initialized' : 'NOT initialized'}`);
    return { sequelize, Transaction };
  } catch (error) {
    logger.error('Unable to connect to the database:', error);
    throw error;
  }
};

const getModels = () => {
  if (!Transaction) {
    throw new Error('Database not initialized. Call connectDB() first.');
  }
  return { Transaction };
};

const getSequelize = () => {
  return sequelize;
};

const isInitialized = () => dbInitialized;

module.exports = { 
  connectDB, 
  getModels, 
  getSequelize,
  isInitialized,
  get sequelize() { return sequelize; },
  get Transaction() { return Transaction; }
};
