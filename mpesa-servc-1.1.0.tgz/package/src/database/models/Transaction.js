const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Transaction = sequelize.define('Transaction', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    merchantRequestId: {
      type: DataTypes.STRING,
      allowNull: true,
      index: true
    },
    checkoutRequestId: {
      type: DataTypes.STRING,
      allowNull: true,
      index: true
    },
    transactionId: {
      type: DataTypes.STRING,
      allowNull: true,
      index: true
    },
    originatorConversationId: {
      type: DataTypes.STRING,
      allowNull: true,
      index: true
    },
    conversationId: {
      type: DataTypes.STRING,
      allowNull: true,
      index: true
    },
    amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false
    },
    phoneNumber: {
      type: DataTypes.STRING,
      allowNull: true
    },
    transactionType: {
      type: DataTypes.STRING, // STK_PUSH, B2C, B2B, C2B, etc.
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('PENDING', 'SUCCESS', 'FAILED', 'CANCELLED', 'TIMEOUT'),
      defaultValue: 'PENDING'
    },
    resultCode: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    resultDesc: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    mpesaReceiptNumber: {
      type: DataTypes.STRING,
      allowNull: true
    },
    rawCallbackData: {
      type: DataTypes.JSON,
      allowNull: true
    },
    accountReference: {
      type: DataTypes.STRING,
      allowNull: true
    },
    transactionDesc: {
      type: DataTypes.STRING,
      allowNull: true
    },
    remarks: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'mpesa_transactions',
    timestamps: true,
    indexes: [
      {
        fields: ['merchantRequestId']
      },
      {
        fields: ['checkoutRequestId']
      },
      {
        fields: ['transactionId']
      }
    ]
  });

  return Transaction;
};
