const express = require('express');
const router = express.Router();
const paymentController = require('../controllers/paymentController');
const { rateLimiter, apiKeyAuth } = require('../middleware/authMiddleware');

router.post('/payments/phone', rateLimiter, apiKeyAuth, paymentController.phonePayment);
router.post('/payments/pochi', rateLimiter, apiKeyAuth, paymentController.pochiPayment);
router.post('/payments/till', rateLimiter, apiKeyAuth, paymentController.tillPayment);
router.post('/payments/paybill', rateLimiter, apiKeyAuth, paymentController.paybillPayment);
router.post('/payments/buy-goods-online', rateLimiter, apiKeyAuth, paymentController.customerBuyGoodsOnline);
router.post('/payments/pay-bill-online', rateLimiter, apiKeyAuth, paymentController.customerPayBillOnline);

module.exports = router;