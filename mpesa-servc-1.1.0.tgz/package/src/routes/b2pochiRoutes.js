const express = require('express');
const router = express.Router();
const b2pochiController = require('../controllers/b2pochiController');
const { strictRateLimiter, apiKeyAuth } = require('../middleware/authMiddleware');

router.post('/b2pochi/payment', strictRateLimiter, apiKeyAuth, b2pochiController.b2pochiPayment);

module.exports = router;