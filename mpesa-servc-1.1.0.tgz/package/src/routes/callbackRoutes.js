const express = require('express');
const router = express.Router();
const callbackController = require('../controllers/callbackController');

router.post('/callback/stkpush', callbackController.handleStkPushCallback);
router.post('/callback/c2b/confirmation', callbackController.handleC2BConfirmation);
router.post('/callback/c2b/validation', callbackController.handleC2BValidation);
router.post('/callback/b2c/result', callbackController.handleB2CResult);
router.post('/callback/b2b/result', callbackController.handleB2BResult);
router.post('/callback/b2pochi/result', callbackController.handleB2PochiResult);
router.post('/callback/account-balance', callbackController.handleAccountBalanceResult);
router.post('/callback/transaction-status', callbackController.handleTransactionStatusResult);
router.post('/callback/reversal', callbackController.handleReversalResult);
router.post('/callback/timeout', callbackController.handleTimeout);

module.exports = router;