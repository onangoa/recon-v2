const express = require('express');
const router = express.Router();
const c2bController = require('../controllers/c2bController');
const { rateLimiter, apiKeyAuth } = require('../middleware/authMiddleware');

router.post('/c2b/register', rateLimiter, apiKeyAuth, c2bController.registerUrls);
router.post('/c2b/simulate', rateLimiter, apiKeyAuth, c2bController.simulateC2B);
router.post('/c2b/buy-goods', rateLimiter, apiKeyAuth, c2bController.customerBuyGoods);
router.post('/c2b/pay-bill', rateLimiter, apiKeyAuth, c2bController.customerPayBill);

module.exports = router;