const express = require('express');
const router = express.Router();
const transactionController = require('../controllers/transactionController');
const { rateLimiter, strictRateLimiter, apiKeyAuth } = require('../middleware/authMiddleware');

router.get('/transactions/local', rateLimiter, apiKeyAuth, transactionController.getLocalTransactions);
router.get('/transactions/local/:id', rateLimiter, apiKeyAuth, transactionController.getLocalTransactionById);
router.post('/transactions/status', rateLimiter, apiKeyAuth, transactionController.checkTransactionStatus);
router.post('/transactions/balance', rateLimiter, apiKeyAuth, transactionController.checkAccountBalance);
router.post('/transactions/reversal', strictRateLimiter, apiKeyAuth, transactionController.reverseTransaction);
router.post('/transactions/query-by-receipt', rateLimiter, apiKeyAuth, transactionController.queryTransactionByReceipt);
router.post('/transactions/query-by-originator-id', rateLimiter, apiKeyAuth, transactionController.queryTransactionByOriginatorID);

module.exports = router;