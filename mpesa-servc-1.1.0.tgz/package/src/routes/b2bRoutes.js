const express = require('express');
const router = express.Router();
const b2bController = require('../controllers/b2bController');
const { strictRateLimiter, apiKeyAuth } = require('../middleware/authMiddleware');

router.post('/b2b/transfer', strictRateLimiter, apiKeyAuth, b2bController.b2bTransfer);
router.post('/b2b/business-pay-bill', strictRateLimiter, apiKeyAuth, b2bController.businessPayBill);
router.post('/b2b/business-buy-goods', strictRateLimiter, apiKeyAuth, b2bController.businessBuyGoods);

module.exports = router;