const express = require('express');
const router = express.Router();
const stkPushController = require('../controllers/stkPushController');
const { rateLimiter, apiKeyAuth, validatePaymentRequest } = require('../middleware/authMiddleware');

router.post('/stkpush/initiate', rateLimiter, apiKeyAuth, validatePaymentRequest, stkPushController.initiateStkPush);
router.get('/stkpush/query/:checkoutRequestID', apiKeyAuth, stkPushController.queryStkPush);

module.exports = router;