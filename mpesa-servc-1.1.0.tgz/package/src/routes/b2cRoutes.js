const express = require('express');
const router = express.Router();
const b2cController = require('../controllers/b2cController');
const { rateLimiter, apiKeyAuth } = require('../middleware/authMiddleware');

router.get('/b2c/test', (req, res) => {
  res.json({ success: true, message: 'B2C test route works' });
});

router.post('/b2c/payment', rateLimiter, apiKeyAuth, b2cController.b2cPayment);
router.post('/b2c/salary', rateLimiter, apiKeyAuth, b2cController.salaryPayment);
router.post('/b2c/business', rateLimiter, apiKeyAuth, b2cController.businessPayment);
router.post('/b2c/promotion', rateLimiter, apiKeyAuth, b2cController.promotionPayment);

module.exports = router;