require('dotenv').config();

const config = {
  mpesa: {
    consumerKey: process.env.MPESA_CONSUMER_KEY,
    consumerSecret: process.env.MPESA_CONSUMER_SECRET,
    passKey: process.env.MPESA_PASSKEY,
    shortCode: process.env.MPESA_SHORTCODE,
    headOffice: process.env.MPESA_HEAD_OFFICE,
    initiatorName: process.env.MPESA_INITIATOR_NAME,
    initiatorPassword: process.env.MPESA_INITIATOR_PASSWORD,
    securityCredential: process.env.MPESA_SECURITY_CREDENTIAL,
    callbackUrl: process.env.MPESA_CALLBACK_URL,
    timeoutUrl: process.env.MPESA_TIMEOUT_URL,
    resultUrl: process.env.MPESA_RESULT_URL,
    b2bResultUrl: process.env.MPESA_B2B_RESULT_URL,
    b2pochiResultUrl: process.env.MPESA_B2POCHI_RESULT_URL,
    accountBalanceResultUrl: process.env.MPESA_ACCOUNT_BALANCE_RESULT_URL,
    transactionStatusResultUrl: process.env.MPESA_TRANSACTION_STATUS_RESULT_URL,
    reversalResultUrl: process.env.MPESA_REVERSAL_RESULT_URL,
    queueTimeoutUrl: process.env.MPESA_QUEUE_TIMEOUT_URL,
    environment: process.env.MPESA_ENVIRONMENT || 'sandbox',
  },
  server: {
    port: process.env.PORT || 3000,
    jwtSecret: process.env.MPESA_JWT_SECRET || process.env.JWT_SECRET,
    apiKey: process.env.API_KEY,
  },
  urls: {
    production: {
      auth: 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials',
      stkPush: 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest',
      stkPushQuery: 'https://api.safaricom.co.ke/mpesa/stkpushquery/v1/query',
      b2c: 'https://api.safaricom.co.ke/mpesa/b2c/v3/paymentrequest',
      b2b: 'https://api.safaricom.co.ke/mpesa/b2b/v1/paymentrequest',
      b2pochi: 'https://api.safaricom.co.ke/mpesa/b2pochi/v1/paymentrequest',
      c2b: {
        register: 'https://api.safaricom.co.ke/mpesa/c2b/v2/registerurl',
        simulate: 'https://api.safaricom.co.ke/mpesa/c2b/v2/simulate'
      },
      accountBalance: 'https://api.safaricom.co.ke/mpesa/accountbalance/v1/query',
      transactionStatus: 'https://api.safaricom.co.ke/mpesa/transactionstatus/v1/query',
      reversal: 'https://api.safaricom.co.ke/mpesa/reversal/v1/request'
    },
    sandbox: {
      auth: 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials',
      stkPush: 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest',
      stkPushQuery: 'https://sandbox.safaricom.co.ke/mpesa/stkpushquery/v1/query',
      b2c: 'https://sandbox.safaricom.co.ke/mpesa/b2c/v3/paymentrequest',
      b2b: 'https://sandbox.safaricom.co.ke/mpesa/b2b/v1/paymentrequest',
      b2pochi: 'https://sandbox.safaricom.co.ke/mpesa/b2pochi/v1/paymentrequest',
      c2b: {
        register: 'https://sandbox.safaricom.co.ke/mpesa/c2b/v2/registerurl',
        simulate: 'https://sandbox.safaricom.co.ke/mpesa/c2b/v2/simulate'
      },
      accountBalance: 'https://sandbox.safaricom.co.ke/mpesa/accountbalance/v1/query',
      transactionStatus: 'https://sandbox.safaricom.co.ke/mpesa/transactionstatus/v1/query',
      reversal: 'https://sandbox.safaricom.co.ke/mpesa/reversal/v1/request'
    }
  }
};

config.getMpesaUrls = () => {
  return config.urls[config.mpesa.environment];
};

module.exports = config;